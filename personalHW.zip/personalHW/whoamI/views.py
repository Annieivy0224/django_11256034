from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def whoamI(request):
    return HttpResponse("台北商業大學<br>五專資管科" \
                        "<br>11256034<br>陳潔如")